﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;



namespace CustomerOrders
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'orderDataSet.TBL_Orders' table. You can move, or remove it, as needed.
            this.tBL_OrdersTableAdapter1.Fill(this.orderDataSet.TBL_Orders);
            // TODO: This line of code loads data into the 'customerDBDataSet2.TBL_OrderReturns' table. You can move, or remove it, as needed.
            this.tBL_OrderReturnsTableAdapter2.Fill(this.customerDBDataSet2.TBL_OrderReturns);
            // TODO: This line of code loads data into the 'orderReturnsDataSet1.TBL_OrderReturns' table. You can move, or remove it, as needed.
            this.tBL_OrderReturnsTableAdapter1.Fill(this.orderReturnsDataSet1.TBL_OrderReturns);
            // TODO: This line of code loads data into the 'orderReturnsDataSet.TBL_OrderReturns' table. You can move, or remove it, as needed.
            this.tBL_OrderReturnsTableAdapter.Fill(this.orderReturnsDataSet.TBL_OrderReturns);
            // TODO: This line of code loads data into the 'customerDBDataSet.TBL_Orders' table. You can move, or remove it, as needed.
            
           }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnExportPdf_Click(object sender, EventArgs e)
        {
            try
            {

                PdfPTable pdfTable_ShipTo = new PdfPTable(2);
                pdfTable_ShipTo.DefaultCell.Padding = 10;
                pdfTable_ShipTo.WidthPercentage = 60;
                pdfTable_ShipTo.HorizontalAlignment = Element.ALIGN_CENTER;
                pdfTable_ShipTo.DefaultCell.BorderWidth = 0;
                pdfTable_ShipTo.SpacingAfter = 20;
                pdfTable_ShipTo.SpacingBefore = 20;



                PdfPTable pdfTable_Orders = new PdfPTable(2);
                pdfTable_Orders.DefaultCell.Padding = 10;
                pdfTable_Orders.WidthPercentage = 60;
                pdfTable_Orders.HorizontalAlignment = Element.ALIGN_CENTER;
                pdfTable_Orders.DefaultCell.BorderWidth = 1;
                pdfTable_Orders.SpacingAfter = 20;
                pdfTable_Orders.SpacingBefore = 20;

                PdfPTable pdfTable = new PdfPTable(Gv_ReturnOrders.ColumnCount);
                pdfTable.DefaultCell.Padding = 10;
                pdfTable.WidthPercentage = 60;
                pdfTable.HorizontalAlignment = Element.ALIGN_CENTER;
                pdfTable.DefaultCell.BorderWidth = 1;
                pdfTable.SpacingAfter = 20;
                pdfTable.SpacingBefore = 20;


                pdfTable_ShipTo.AddCell("Ship To:" + Environment.NewLine + orderDataSet.Tables[0].Rows[0][3].ToString());

                pdfTable_ShipTo.AddCell("Business");

                //here we can do dynamic by using for loop with i,j for rows and columns
                for (int i = 0; i < Gv_orders.RowCount - 1; i++)
                { 
                pdfTable_Orders.AddCell("Ship To:" + Environment.NewLine + orderDataSet.Tables[0].Rows[i][3].ToString());
                pdfTable_Orders.AddCell("BuyerName:" + Gv_orders.Rows[i].Cells[2].Value.ToString() + Environment.NewLine + "Order date:" + Gv_orders.Rows[i].Cells[1].Value.ToString());

            }
                
                //Adding Header row
                foreach (DataGridViewColumn column in Gv_ReturnOrders.Columns)
                {
                    PdfPCell cell = new PdfPCell(new Phrase(column.HeaderText));
                    //cell.BackgroundColor = new iTextSharp.text.Color(240, 240, 240);                    
                    pdfTable.AddCell(cell);
                }
                //Adding DataRow
                foreach (DataGridViewRow row in Gv_ReturnOrders.Rows)
                {

                    foreach (DataGridViewCell cell in row.Cells)
                    {
                        if (cell.Value != null)
                            pdfTable.AddCell(cell.Value.ToString());
                    }
                }

                //Exporting to PDF
                string folderPath = "C:\\PDFs\\";
                if (!Directory.Exists(folderPath))
                {
                    Directory.CreateDirectory(folderPath);
                }
                Paragraph p = new Paragraph("Shiping To:"+ orderDataSet.Tables[0].Rows[0][3].ToString());
                using (FileStream stream = new FileStream(folderPath + "Orders.pdf", FileMode.Create))
                {
                    Document pdfDoc = new Document(PageSize.A2, 10f, 10f, 10f, 0f);
                    PdfWriter.GetInstance(pdfDoc, stream);
                    pdfDoc.Open();
                    //pdfDoc.Add(p);
                    pdfDoc.Add(pdfTable_ShipTo);
                    pdfDoc.Add(pdfTable_Orders);
                    pdfDoc.Add(pdfTable);
                    pdfDoc.Close();
                    stream.Close();
                }
                MessageBox.Show("PDF Generatd Success");
            }
            catch(Exception ex)
            {
                MessageBox.Show("pdf Generation Failed");
            }
        }

        private void Gv_orders_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
