﻿namespace CustomerOrders
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tBLOrdersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.customerDBDataSet = new CustomerOrders.CustomerDBDataSet();
            this.tBL_OrdersTableAdapter = new CustomerOrders.CustomerDBDataSetTableAdapters.TBL_OrdersTableAdapter();
            this.Gv_ReturnOrders = new System.Windows.Forms.DataGridView();
            this.returnTypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.returnReasonDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.commentsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.additionalCommentsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tBLOrderReturnsBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.customerDBDataSet2 = new CustomerOrders.CustomerDBDataSet2();
            this.orderReturnsDataSet = new CustomerOrders.OrderReturnsDataSet();
            this.tBLOrderReturnsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tBL_OrderReturnsTableAdapter = new CustomerOrders.OrderReturnsDataSetTableAdapters.TBL_OrderReturnsTableAdapter();
            this.orderReturnsDataSet1 = new CustomerOrders.OrderReturnsDataSet1();
            this.tBLOrderReturnsBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.tBL_OrderReturnsTableAdapter1 = new CustomerOrders.OrderReturnsDataSet1TableAdapters.TBL_OrderReturnsTableAdapter();
            this.tBL_OrderReturnsTableAdapter2 = new CustomerOrders.CustomerDBDataSet2TableAdapters.TBL_OrderReturnsTableAdapter();
            this.btnExportPdf = new System.Windows.Forms.Button();
            this.Gv_orders = new System.Windows.Forms.DataGridView();
            this.orderDataSet = new CustomerOrders.OrderDataSet();
            this.tBLOrdersBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.tBL_OrdersTableAdapter1 = new CustomerOrders.OrderDataSetTableAdapters.TBL_OrdersTableAdapter();
            this.shipToDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.buyerNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.orderDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.tBLOrdersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerDBDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Gv_ReturnOrders)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLOrderReturnsBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerDBDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderReturnsDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLOrderReturnsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderReturnsDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLOrderReturnsBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Gv_orders)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLOrdersBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // tBLOrdersBindingSource
            // 
            this.tBLOrdersBindingSource.DataMember = "TBL_Orders";
            this.tBLOrdersBindingSource.DataSource = this.customerDBDataSet;
            // 
            // customerDBDataSet
            // 
            this.customerDBDataSet.DataSetName = "CustomerDBDataSet";
            this.customerDBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tBL_OrdersTableAdapter
            // 
            this.tBL_OrdersTableAdapter.ClearBeforeFill = true;
            // 
            // Gv_ReturnOrders
            // 
            this.Gv_ReturnOrders.AllowUserToOrderColumns = true;
            this.Gv_ReturnOrders.AutoGenerateColumns = false;
            this.Gv_ReturnOrders.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Gv_ReturnOrders.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Gv_ReturnOrders.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.returnTypeDataGridViewTextBoxColumn,
            this.returnReasonDataGridViewTextBoxColumn,
            this.commentsDataGridViewTextBoxColumn,
            this.additionalCommentsDataGridViewTextBoxColumn});
            this.Gv_ReturnOrders.DataSource = this.tBLOrderReturnsBindingSource2;
            this.Gv_ReturnOrders.Location = new System.Drawing.Point(113, 209);
            this.Gv_ReturnOrders.Name = "Gv_ReturnOrders";
            this.Gv_ReturnOrders.Size = new System.Drawing.Size(437, 150);
            this.Gv_ReturnOrders.TabIndex = 3;
            this.Gv_ReturnOrders.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // returnTypeDataGridViewTextBoxColumn
            // 
            this.returnTypeDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.returnTypeDataGridViewTextBoxColumn.DataPropertyName = "ReturnType";
            this.returnTypeDataGridViewTextBoxColumn.HeaderText = "Return Type";
            this.returnTypeDataGridViewTextBoxColumn.Name = "returnTypeDataGridViewTextBoxColumn";
            this.returnTypeDataGridViewTextBoxColumn.Width = 84;
            // 
            // returnReasonDataGridViewTextBoxColumn
            // 
            this.returnReasonDataGridViewTextBoxColumn.DataPropertyName = "ReturnReason";
            this.returnReasonDataGridViewTextBoxColumn.HeaderText = "Return Reason";
            this.returnReasonDataGridViewTextBoxColumn.Name = "returnReasonDataGridViewTextBoxColumn";
            // 
            // commentsDataGridViewTextBoxColumn
            // 
            this.commentsDataGridViewTextBoxColumn.DataPropertyName = "Comments";
            this.commentsDataGridViewTextBoxColumn.HeaderText = "Comments";
            this.commentsDataGridViewTextBoxColumn.Name = "commentsDataGridViewTextBoxColumn";
            // 
            // additionalCommentsDataGridViewTextBoxColumn
            // 
            this.additionalCommentsDataGridViewTextBoxColumn.DataPropertyName = "AdditionalComments";
            this.additionalCommentsDataGridViewTextBoxColumn.HeaderText = "Additional Comments";
            this.additionalCommentsDataGridViewTextBoxColumn.Name = "additionalCommentsDataGridViewTextBoxColumn";
            // 
            // tBLOrderReturnsBindingSource2
            // 
            this.tBLOrderReturnsBindingSource2.DataMember = "TBL_OrderReturns";
            this.tBLOrderReturnsBindingSource2.DataSource = this.customerDBDataSet2;
            // 
            // customerDBDataSet2
            // 
            this.customerDBDataSet2.DataSetName = "CustomerDBDataSet2";
            this.customerDBDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // orderReturnsDataSet
            // 
            this.orderReturnsDataSet.DataSetName = "OrderReturnsDataSet";
            this.orderReturnsDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tBLOrderReturnsBindingSource
            // 
            this.tBLOrderReturnsBindingSource.DataMember = "TBL_OrderReturns";
            this.tBLOrderReturnsBindingSource.DataSource = this.orderReturnsDataSet;
            // 
            // tBL_OrderReturnsTableAdapter
            // 
            this.tBL_OrderReturnsTableAdapter.ClearBeforeFill = true;
            // 
            // orderReturnsDataSet1
            // 
            this.orderReturnsDataSet1.DataSetName = "OrderReturnsDataSet1";
            this.orderReturnsDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tBLOrderReturnsBindingSource1
            // 
            this.tBLOrderReturnsBindingSource1.DataMember = "TBL_OrderReturns";
            this.tBLOrderReturnsBindingSource1.DataSource = this.orderReturnsDataSet1;
            // 
            // tBL_OrderReturnsTableAdapter1
            // 
            this.tBL_OrderReturnsTableAdapter1.ClearBeforeFill = true;
            // 
            // tBL_OrderReturnsTableAdapter2
            // 
            this.tBL_OrderReturnsTableAdapter2.ClearBeforeFill = true;
            // 
            // btnExportPdf
            // 
            this.btnExportPdf.Location = new System.Drawing.Point(213, 380);
            this.btnExportPdf.Name = "btnExportPdf";
            this.btnExportPdf.Size = new System.Drawing.Size(75, 23);
            this.btnExportPdf.TabIndex = 5;
            this.btnExportPdf.Text = "ExportPdf";
            this.btnExportPdf.UseVisualStyleBackColor = true;
            this.btnExportPdf.Click += new System.EventHandler(this.btnExportPdf_Click);
            // 
            // Gv_orders
            // 
            this.Gv_orders.AutoGenerateColumns = false;
            this.Gv_orders.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Gv_orders.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.Gv_orders.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.shipToDataGridViewTextBoxColumn,
            this.buyerNameDataGridViewTextBoxColumn,
            this.orderDateDataGridViewTextBoxColumn});
            this.Gv_orders.DataSource = this.tBLOrdersBindingSource1;
            this.Gv_orders.Location = new System.Drawing.Point(103, 28);
            this.Gv_orders.Name = "Gv_orders";
            this.Gv_orders.Size = new System.Drawing.Size(447, 150);
            this.Gv_orders.TabIndex = 6;
            this.Gv_orders.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Gv_orders_CellContentClick);
            // 
            // orderDataSet
            // 
            this.orderDataSet.DataSetName = "OrderDataSet";
            this.orderDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tBLOrdersBindingSource1
            // 
            this.tBLOrdersBindingSource1.DataMember = "TBL_Orders";
            this.tBLOrdersBindingSource1.DataSource = this.orderDataSet;
            // 
            // tBL_OrdersTableAdapter1
            // 
            this.tBL_OrdersTableAdapter1.ClearBeforeFill = true;
            // 
            // shipToDataGridViewTextBoxColumn
            // 
            this.shipToDataGridViewTextBoxColumn.DataPropertyName = "ShipTo";
            this.shipToDataGridViewTextBoxColumn.HeaderText = "ShipTo";
            this.shipToDataGridViewTextBoxColumn.Name = "shipToDataGridViewTextBoxColumn";
            // 
            // buyerNameDataGridViewTextBoxColumn
            // 
            this.buyerNameDataGridViewTextBoxColumn.DataPropertyName = "BuyerName";
            this.buyerNameDataGridViewTextBoxColumn.HeaderText = "BuyerName";
            this.buyerNameDataGridViewTextBoxColumn.Name = "buyerNameDataGridViewTextBoxColumn";
            // 
            // orderDateDataGridViewTextBoxColumn
            // 
            this.orderDateDataGridViewTextBoxColumn.DataPropertyName = "OrderDate";
            this.orderDateDataGridViewTextBoxColumn.HeaderText = "OrderDate";
            this.orderDateDataGridViewTextBoxColumn.Name = "orderDateDataGridViewTextBoxColumn";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1012, 450);
            this.Controls.Add(this.Gv_orders);
            this.Controls.Add(this.btnExportPdf);
            this.Controls.Add(this.Gv_ReturnOrders);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tBLOrdersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerDBDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Gv_ReturnOrders)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLOrderReturnsBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.customerDBDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderReturnsDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLOrderReturnsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderReturnsDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLOrderReturnsBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Gv_orders)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.orderDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tBLOrdersBindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private CustomerDBDataSet customerDBDataSet;
        private System.Windows.Forms.BindingSource tBLOrdersBindingSource;
        private CustomerDBDataSetTableAdapters.TBL_OrdersTableAdapter tBL_OrdersTableAdapter;
        private System.Windows.Forms.DataGridView Gv_ReturnOrders;
        private OrderReturnsDataSet orderReturnsDataSet;
        private System.Windows.Forms.BindingSource tBLOrderReturnsBindingSource;
        private OrderReturnsDataSetTableAdapters.TBL_OrderReturnsTableAdapter tBL_OrderReturnsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn returnTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn returnReasonDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn commentsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn additionalCommentsDataGridViewTextBoxColumn;
        private OrderReturnsDataSet1 orderReturnsDataSet1;
        private System.Windows.Forms.BindingSource tBLOrderReturnsBindingSource1;
        private OrderReturnsDataSet1TableAdapters.TBL_OrderReturnsTableAdapter tBL_OrderReturnsTableAdapter1;
        private CustomerDBDataSet2 customerDBDataSet2;
        private System.Windows.Forms.BindingSource tBLOrderReturnsBindingSource2;
        private CustomerDBDataSet2TableAdapters.TBL_OrderReturnsTableAdapter tBL_OrderReturnsTableAdapter2;
        private System.Windows.Forms.Button btnExportPdf;
        private System.Windows.Forms.DataGridView Gv_orders;
        private OrderDataSet orderDataSet;
        private System.Windows.Forms.BindingSource tBLOrdersBindingSource1;
        private OrderDataSetTableAdapters.TBL_OrdersTableAdapter tBL_OrdersTableAdapter1;
        private System.Windows.Forms.DataGridViewTextBoxColumn shipToDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn buyerNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn orderDateDataGridViewTextBoxColumn;
    }
}

